﻿using hey.Service.Implementation;
using hey.Service.Interface;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using Test.Models;
using Test.ViewModels;

namespace tests
{
    public class UrlsControllerTest
    {
        private Mock<IUrlService> _serviceMockCreate;
        private Mock<IUrlService> _serviceMockSave;
        private Mock<IUrlService> _serviceMockLastUrls;
        private Mock<IUrlService> _serviceMockRegisterVisit;
        private Mock<IUrlService> _serviceMockShowInformation;

        private IUrlService _serviceCreate;
        private IUrlService _serviceSave;
        private IUrlService _serviceLastUrls;
        private IUrlService _serviceRegisterVisit;
        private IUrlService _serviceShowInformation;

        [SetUp]
        public void Setup()
        {
            _serviceMockCreate = new Mock<IUrlService>();
            _serviceMockCreate.Setup(m => m.CreateShortUrl("http://www.google.com")).Returns("GOOGL");
            _serviceCreate = _serviceMockCreate.Object;

            _serviceMockSave = new Mock<IUrlService>();
            _serviceMockSave.Setup(m => m.SavelUrl("http://www.google.com", "GOOGL")).Returns(true);
            _serviceSave = _serviceMockSave.Object;

            _serviceMockRegisterVisit = new Mock<IUrlService>();
            _serviceMockRegisterVisit.Setup(m => m.RegisterVisit("GOOGL")).Returns(true);
            _serviceRegisterVisit = _serviceMockRegisterVisit.Object;

            var _createFakeShowViewModel = new ShowViewModel();

            _createFakeShowViewModel.Url = new Url()
            {
                ShortUrl = "GOOGL",
                Count = 1,
                Id = Guid.NewGuid()
            };

            var _dicBrowser = new Dictionary<string, int>();

            _dicBrowser.Add(UrlService.BROWSE_TYPE_IE, 0);
            _dicBrowser.Add(UrlService.BROWSE_TYPE_FIRE_FOX, 1);
            _dicBrowser.Add(UrlService.BROWSE_TYPE_CHROME, 1);
            _dicBrowser.Add(UrlService.BROWSE_TYPE_SAFARI, 0);

            _createFakeShowViewModel.BrowseClicks = _dicBrowser;

            var _dicPlatform = new Dictionary<string, int>();

            _dicPlatform.Add(UrlService.PLATFORM_WINDOWS, 1);
            _dicPlatform.Add(UrlService.PLATFORM_MACOS, 0);
            _dicPlatform.Add(UrlService.PLATFORM_UBUNTU, 0);
            _dicPlatform.Add(UrlService.PLATFORM_OTHER, 0);

            _createFakeShowViewModel.PlatformClicks = _dicPlatform;

            var _dicDays = this.CreateDictoryClicksByDay(_createFakeShowViewModel.Url);

            _createFakeShowViewModel.DailyClicks = _dicDays;

            _serviceMockShowInformation = new Mock<IUrlService>();
            _serviceMockShowInformation.Setup(m => m.GetShowInformation("GOOGL")).Returns(_createFakeShowViewModel);
            _serviceShowInformation = _serviceMockShowInformation.Object;

            _serviceMockLastUrls = new Mock<IUrlService>();
            _serviceMockLastUrls.Setup(m => m.GetLastUrls()).Returns(
                new List<Url>()
                {
                    new Url()
                    {
                        BrowseChrome = 1,
                        BrowserFireFox = 0,
                        BrowserIE = 0,
                        BrowseSafari = 0,
                        Count = 1,
                        Created = DateTime.Now,
                        Id = Guid.NewGuid(),
                        PlatformMacos = 0,
                        PlatformOther = 0,
                        PlatformUbuntu = 0,
                        PlatformWindows = 1,
                        ShortUrl = "GOOGL",
                        Stats = 0,
                        UrlOriginal = "http://www.google.com"
                    }
                });
            _serviceLastUrls = _serviceMockLastUrls.Object;

        }

        private Dictionary<string, int> CreateDictoryClicksByDay(Url url)
        {
            var _result = new Dictionary<string, int>();
            var _numDays = 31;
            var _dateHistory = new List<Visit>();

            for (var i = 1; i <= _numDays; i++)
                _result.Add(i.ToString(), 0);

            _result["03"] = 1;

            return (_result);
        }

        [Test]
        public void TestIndex()
        {
            var _resultCreate = this._serviceCreate.CreateShortUrl("http://www.google.com");

            Assert.IsTrue(_resultCreate == "GOOGL");

            var _resultSave = this._serviceSave.SavelUrl("http://www.google.com", "GOOGL");

            Assert.IsTrue(_resultSave, "Url Saved");

            var _resultLastUrls = this._serviceLastUrls.GetLastUrls();

            Assert.AreEqual(1, _resultLastUrls.Count);

            var _resultRegisterVisit = this._serviceRegisterVisit.RegisterVisit("GOOGL");

            Assert.AreEqual(true, _resultRegisterVisit);

            var _resultShowInformation = this._serviceShowInformation.GetShowInformation("GOOGL");

            Assert.AreEqual("GOOGL", _resultShowInformation.Url.ShortUrl);
        }
    }
}