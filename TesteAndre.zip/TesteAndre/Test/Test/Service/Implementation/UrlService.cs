﻿using hey.Service.Interface;
using Shyjus.BrowserDetection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Test.Data;
using Test.Models;
using Test.ViewModels;

namespace hey.Service.Implementation
{
    public class UrlService: IUrlService
    {
        public const string BROWSE_TYPE_IE = "IE";
        public const string BROWSE_TYPE_FIRE_FOX = "Firefox";
        public const string BROWSE_TYPE_CHROME = "Chrome";
        public const string BROWSE_TYPE_SAFARI = "Safari";
        public const string PLATFORM_WINDOWS = "Windows";
        public const string PLATFORM_MACOS = "macOS";
        public const string PLATFORM_UBUNTU = "Ubuntu";
        public const string PLATFORM_OTHER = "Other";
        public const int JANUARY = 1;
        public const int FEBRUARY = 2;
        public const int MARCH = 3;
        public const int APRIL = 4;
        public const int MAY = 5;
        public const int JUNE = 6;
        public const int JULY = 7;
        public const int AUGUST = 8;
        public const int SEPTEMBER = 9;
        public const int OCTOBER = 10;
        public const int NOVEMBER = 11;
        public string[] Alphabet = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        private readonly ApplicationContext _context;
        private readonly IBrowserDetector browserDetector;

        public UrlService(ApplicationContext context, IBrowserDetector browserDetector)
        {
            this._context = context;
            this.browserDetector = browserDetector;
        }

        public ShowViewModel GetShowInformation(string url)
        {
            var _result = new ShowViewModel();
            var _objectUrl = this._context.Urls.Where(i => i.ShortUrl == url).FirstOrDefault();

            if (_objectUrl == null)
                return (null);

            _result.Url = new Url()
            {
                ShortUrl = url,
                Count = _objectUrl.Count
            };

            var _dicBrowser = new Dictionary<string, int>();

            _dicBrowser.Add(BROWSE_TYPE_IE, _objectUrl.BrowserIE);
            _dicBrowser.Add(BROWSE_TYPE_FIRE_FOX, _objectUrl.BrowserFireFox);
            _dicBrowser.Add(BROWSE_TYPE_CHROME, _objectUrl.BrowseChrome);
            _dicBrowser.Add(BROWSE_TYPE_SAFARI, _objectUrl.BrowseSafari);

            _result.BrowseClicks = _dicBrowser;

            var _dicPlatform = new Dictionary<string, int>();

            _dicPlatform.Add(PLATFORM_WINDOWS, _objectUrl.PlatformWindows);
            _dicPlatform.Add(PLATFORM_MACOS, _objectUrl.PlatformMacos);
            _dicPlatform.Add(PLATFORM_UBUNTU, _objectUrl.PlatformUbuntu);
            _dicPlatform.Add(PLATFORM_OTHER, _objectUrl.PlatformOther);

            _result.PlatformClicks = _dicPlatform;
            _result.Url = _objectUrl;

            var _dicDays = this.CreateDictoryClicksByDay(_objectUrl);

            _result.DailyClicks = _dicDays;

            return (_result);
        }

        public bool SavelUrl(string urlOriginal, string shortName)
        {
            var _newUrlObject = new Url()
            {
                UrlOriginal = urlOriginal,
                ShortUrl = shortName,
                Count = 0,
                Created = DateTime.Now,
                Id = Guid.NewGuid(),
                Stats = 0
            };

            this._context.Urls.Add(_newUrlObject);
            this._context.SaveChanges();

            return (true);
        }

        public bool RegisterVisit(string url)
        {
            var _objetctUrl = this._context.Urls.Where(i => i.ShortUrl == url).FirstOrDefault();

            if (_objetctUrl == null)
                return (false);

            _objetctUrl.Count++;

            if (this.browserDetector.Browser.Name == BROWSE_TYPE_IE)
                _objetctUrl.BrowserIE++;
            else if (this.browserDetector.Browser.Name == BROWSE_TYPE_FIRE_FOX)
                _objetctUrl.BrowserFireFox++;
            else if (this.browserDetector.Browser.Name == BROWSE_TYPE_CHROME)
                _objetctUrl.BrowseChrome++;
            else if (this.browserDetector.Browser.Name == BROWSE_TYPE_SAFARI)
                _objetctUrl.BrowseSafari++;

            if (this.browserDetector.Browser.OS == PLATFORM_WINDOWS)
                _objetctUrl.PlatformWindows++;
            else if (this.browserDetector.Browser.OS == PLATFORM_MACOS)
                _objetctUrl.PlatformMacos++;
            else if (this.browserDetector.Browser.OS == PLATFORM_UBUNTU)
                _objetctUrl.PlatformUbuntu++;
            else
                _objetctUrl.PlatformOther++;

            this._context.Update(_objetctUrl);

            var _visit = new Visit()
            {
                DateVisit = DateTime.Now,
                Id = Guid.NewGuid(),
                UrlId = _objetctUrl.Id
            };

            this._context.Visits.Add(_visit);
            this._context.SaveChanges();

            return (true);
        }

        public List<Url> GetLastUrls()
        {
            return (this._context.Urls.OrderByDescending(i => i.Created).Take(10).ToList());
        }

        public string CreateShortUrl(string urlOriginal)
        {
            return (this.CreateShortUrl(new Uri(urlOriginal)));
        }

        private string CreateShortUrl(Uri newUrl)
        {
            var _path = newUrl.Authority.Replace("www.", "");
            var _com = _path.IndexOf(".com");

            if (_com != -1)
                _path = _path.Substring(0, _com);

            var _pos = _path.IndexOf("/");

            if (_pos != -1)
                _path = _path.Substring(0, _pos);

            return (this.PrepareName(_path));
        }

        private string PrepareName(string name)
        {
            var _shortName = name;

            if (_shortName.Length != 5)
                _shortName = this.CreateShortUrlName(name);

            var _valid = this.IsShortUrlUnique(_shortName);

            while (!_valid)
            {
                _shortName = this.CreateShortUrlName();
                _valid = this.IsShortUrlUnique(_shortName);
            }

            return (_shortName);
        }

        private string CreateShortUrlName()
        {
            var _localName = new StringBuilder();
            var _random = new Random();
            var _seed = 0;

            for (var i = 0; i < (5 - _localName.ToString().Length); i++)
            {
                _seed = _random.Next(0, Alphabet.Length - 1);
                _localName.Append(Alphabet[_seed]);
            }

            return (_localName.ToString());
        }

        private string CreateShortUrlName(string name)
        {
            var _regEx = new Regex("^[a-zA-Z]*$");
            var _tempName = new StringBuilder();
            var _auxName = string.Empty;

            for (var i = 0; ((_tempName.Length != 5) && i <= name.Length - 1); i++)
            {
                if (_regEx.IsMatch(name[i].ToString()))
                    _tempName.Append(name[i].ToString().ToUpper());
            }

            _auxName = _tempName.ToString();

            if (_auxName.Length != 5)
                _auxName = this.CompleteName(_auxName);

            return (_auxName);
        }

        private bool IsShortUrlUnique(string name)
        {
            if (this._context.Urls.Where(i => i.ShortUrl == name).Count() == 0)
                return (true);
            else
                return (false);
        }

        private string CompleteName(string name)
        {
            var _localName = new StringBuilder();
            var _random = new Random();
            var _seed = 0;

            _localName.Append(name);

            for (var i = 0; i < (5 - _localName.ToString().Length); i++)
            {
                _seed = _random.Next(0, Alphabet.Length - 1);
                _localName.Append(Alphabet[_seed]);
            }

            return (_localName.ToString());
        }

        private Dictionary<string, int> CreateDictoryClicksByDay(Url url)
        {
            var _dateHistory = this._context.Visits.Where(i => i.UrlId == url.Id && i.DateVisit.Month == DateTime.Today.Month).ToList();
            var _result = new Dictionary<string, int>();
            var _numDays = this.GetNumberDaysByMonth(DateTime.Today.Month);

            for (var i = 1; i <= _numDays; i++)
                _result.Add(i.ToString(), 0);

            foreach (var _date in _dateHistory)
                _result[_date.DateVisit.Day.ToString()] = _result[_date.DateVisit.Day.ToString()] + 1;

            return (_result);
        }

        private int GetNumberDaysByMonth(int month)
        {
            if (month == JANUARY || month == MARCH || month == MAY || month == JULY || month == AUGUST || month == OCTOBER)
                return (31);
            else if (month == FEBRUARY)
            {
                if (this.IsLeapYear(DateTime.Now.Year))
                    return (29);
                else
                    return (28);
            }
            else if (month == APRIL || month == JUNE || month == SEPTEMBER || month == NOVEMBER)
                return (30);
            else
                return (31);
        }

        private bool IsLeapYear(int year)
        {
            return (DateTime.IsLeapYear(year));
        }
    }
}