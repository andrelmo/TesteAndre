﻿using System.Collections.Generic;
using Test.Models;
using Test.ViewModels;

namespace hey.Service.Interface
{
    public interface IUrlService
    {
        bool SavelUrl(string urlOriginal, string shortName);
        string CreateShortUrl(string urlOriginal);
        List<Url> GetLastUrls();
        bool RegisterVisit(string url);
        ShowViewModel GetShowInformation(string url);
    }
}