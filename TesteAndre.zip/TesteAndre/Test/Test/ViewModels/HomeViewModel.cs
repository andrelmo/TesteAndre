﻿using System.Collections.Generic;
using Test.Models;

namespace Test.ViewModels
{
    public class HomeViewModel
    {
        public IEnumerable<Url> Urls { get; set; }
        public Url NewUrl { get; set; }
    }
}
