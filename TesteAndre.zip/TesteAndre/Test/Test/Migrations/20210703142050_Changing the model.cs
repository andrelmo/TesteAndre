﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Test.Migrations
{
    public partial class Changingthemodel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Url",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ShortUrl = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    UrlOriginal = table.Column<string>(type: "nvarchar(4000)", maxLength: 4000, nullable: true),
                    Count = table.Column<int>(type: "int", nullable: false),
                    Created = table.Column<DateTime>(type: "DateTime", nullable: false),
                    Stats = table.Column<int>(type: "int", nullable: false),
                    PlaformWindows = table.Column<int>(type: "int", nullable: false),
                    PlatformMacos = table.Column<int>(type: "int", nullable: false),
                    PlatformUbuntu = table.Column<int>(type: "int", nullable: false),
                    PlatformOther = table.Column<int>(type: "int", nullable: false),
                    BrowseIE = table.Column<int>(type: "int", nullable: false),
                    BrowseFireFox = table.Column<int>(type: "int", nullable: false),
                    BrowseChrome = table.Column<int>(name: "BrowseChrome'", type: "int", nullable: false),
                    BrowseSafari = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Url", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Visit",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DateVisit = table.Column<DateTime>(type: "DateTime", nullable: false),
                    UrlId = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Visit", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Visit_Url_UrlId",
                        column: x => x.UrlId,
                        principalTable: "Url",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Visit_UrlId",
                table: "Visit",
                column: "UrlId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Visit");

            migrationBuilder.DropTable(
                name: "Url");
        }
    }
}
