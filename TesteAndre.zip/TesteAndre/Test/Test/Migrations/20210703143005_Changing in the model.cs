﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Test.Migrations
{
    public partial class Changinginthemodel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Visit_Url_UrlId",
                table: "Visit");

            migrationBuilder.DropIndex(
                name: "IX_Visit_UrlId",
                table: "Visit");

            migrationBuilder.AlterColumn<Guid>(
                name: "UrlId",
                table: "Visit",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"),
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier",
                oldNullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<Guid>(
                name: "UrlId",
                table: "Visit",
                type: "uniqueidentifier",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier");

            migrationBuilder.CreateIndex(
                name: "IX_Visit_UrlId",
                table: "Visit",
                column: "UrlId");

            migrationBuilder.AddForeignKey(
                name: "FK_Visit_Url_UrlId",
                table: "Visit",
                column: "UrlId",
                principalTable: "Url",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
