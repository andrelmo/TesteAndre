﻿namespace Test.Models
{
    public class NewUrl
    {
        public string UrlOriginal { get; set; }
    }
}