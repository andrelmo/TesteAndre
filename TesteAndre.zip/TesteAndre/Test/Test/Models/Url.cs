﻿using System;

namespace Test.Models
{
    public class Url
    {
        public Guid Id { get; set; }
        public string ShortUrl { get; set; }
        public string UrlOriginal { get; set; }
        public int Count { get; set; }
        public DateTime Created { get; set; }
        public int Stats { get; set; }
        public int PlatformWindows { get; set; }
        public int PlatformMacos { get; set; }
        public int PlatformUbuntu { get; set; }
        public int PlatformOther { get; set; }
        public int BrowserIE { get; set; }
        public int BrowserFireFox { get; set; }
        public int BrowseChrome { get; set; }
        public int BrowseSafari { get; set; }

        public Url()
        {
            
        }
    }
}
