﻿using System;

namespace Test.Models
{
    public class Visit
    {
        public Guid Id { get; set; }
        public DateTime DateVisit { get; set; }
        public Guid UrlId { get; set; }
    }
}