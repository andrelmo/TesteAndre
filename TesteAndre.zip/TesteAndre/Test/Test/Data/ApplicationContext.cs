﻿using Microsoft.EntityFrameworkCore;
using Test.Models;

namespace Test.Data
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        {

        }

        public DbSet<Url> Urls { get; set; }
        public DbSet<Visit> Visits { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            this.ConfigureUrl(modelBuilder);
            this.ConfigureVisit(modelBuilder);
        }

        private void ConfigureVisit(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Visit>
                (
                    etd =>
                    {
                        etd.ToTable("Visit");
                        etd.HasKey(c => c.Id);
                        etd.Property(c => c.DateVisit).HasColumnName("DateVisit").HasColumnType("DateTime");
                        etd.Property(c => c.UrlId).HasColumnName("UrlId");
                    }
                );
        }

        private void ConfigureUrl(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Url>
                (
                    etd =>
                    {
                        etd.ToTable("Url");
                        etd.HasKey(c => c.Id);
                        etd.Property(c => c.Id).HasColumnName("Id");
                        etd.Property(c => c.BrowseChrome).HasColumnName("BrowseChrome'").HasColumnType("int");
                        etd.Property(c => c.BrowserFireFox).HasColumnName("BrowseFireFox").HasColumnType("int");
                        etd.Property(c => c.BrowserIE).HasColumnName("BrowseIE").HasColumnType("int");
                        etd.Property(c => c.BrowseSafari).HasColumnName("BrowseSafari").HasColumnType("int");
                        etd.Property(c => c.Count).HasColumnName("Count").HasColumnType("int");
                        etd.Property(c => c.Created).HasColumnName("Created").HasColumnType("DateTime");
                        etd.Property(c => c.PlatformMacos).HasColumnName("PlatformMacos").HasColumnType("int");
                        etd.Property(c => c.PlatformOther).HasColumnName("PlatformOther").HasColumnType("int");
                        etd.Property(c => c.PlatformUbuntu).HasColumnName("PlatformUbuntu").HasColumnType("int");
                        etd.Property(c => c.PlatformWindows).HasColumnName("PlaformWindows").HasColumnType("int");
                        etd.Property(c => c.ShortUrl).HasColumnName("ShortUrl").HasMaxLength(5);
                        etd.Property(c => c.Stats).HasColumnName("Stats").HasColumnType("int");
                        etd.Property(c => c.UrlOriginal).HasColumnName("UrlOriginal").HasMaxLength(4000);
                    }
                );
        }
    }
}