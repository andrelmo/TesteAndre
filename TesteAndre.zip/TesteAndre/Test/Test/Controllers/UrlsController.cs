﻿using hey.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Shyjus.BrowserDetection;
using System;
using System.Collections.Generic;
using System.Linq;
using Test.Data;
using Test.Models;
using Test.ViewModels;

namespace Test.Controllers
{
    [Route("/")]
    public class UrlsController : Controller
    {
        private readonly ILogger<UrlsController> _logger;
        private static readonly Random getrandom = new Random();
        private readonly IBrowserDetector browserDetector;
        private readonly ApplicationContext _context;
        private readonly IUrlService _urlService;

        public UrlsController(ILogger<UrlsController> logger, IBrowserDetector browserDetector,
            ApplicationContext context, IUrlService urlService)
        {
            this.browserDetector = browserDetector;
            _logger = logger;
            this._context = context;
            this._urlService = urlService;
        }

        [HttpPost]
        public IActionResult Create([FromForm] NewUrl newUrl)
        {
            if (!ModelState.IsValid)
                return (BadRequest());

            try
            {
                if (string.IsNullOrEmpty(newUrl.UrlOriginal))
                    return (BadRequest("Property UrlOriginal can not be empty"));

                if (!Uri.IsWellFormedUriString(newUrl.UrlOriginal, UriKind.Absolute))
                    return (BadRequest($"Url {newUrl.UrlOriginal} is not valid!"));

                var _shortName = this._urlService.CreateShortUrl(newUrl.UrlOriginal);
                var _result = this._urlService.SavelUrl(newUrl.UrlOriginal, _shortName);

                if (_result)
                    return (RedirectToAction("Index"));

                return (BadRequest("There was an error saving the short url"));
            }
            catch (Exception Ex)
            {
                return (BadRequest($"Error: {Ex.Message}"));
            }
        }

        public IActionResult Index()
        {
            var model = new HomeViewModel();
            var _last = this._urlService.GetLastUrls();
            var _listResult = new List<Url>();

            model.Urls = new List<Url>();

            foreach (var _url in _last)
                _listResult.Add(_url);

            model.Urls = _listResult.ToList();
            model.NewUrl = new();

            return View(model);
        }

        [Route("/{url}")]
        public IActionResult Visit(string url)
        {
            var _objetctUrl = this._context.Urls.Where(i => i.ShortUrl == url).FirstOrDefault();

            if (_objetctUrl == null)
                return (NotFound($"Url {url} not found!"));

            var _result = this._urlService.RegisterVisit(url);

            if (_result)
                return (RedirectToAction("Index"));

            return (BadRequest("There was an error in the registration of the visit"));
        }


        [Route("urls/{url}")]
        public IActionResult Show(string url)
        {
            if (string.IsNullOrEmpty(url))
                return (BadRequest("Url can not be empty"));

            var _result = this._urlService.GetShowInformation(url);

            if (_result == null)
                return BadRequest("An error occurred while getting statistical information");

            return (View(_result));
        }
    }
}